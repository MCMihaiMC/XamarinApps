//
// © Copyright IBM Corp. 2018
//
// All Rights Reserved.
//
// This software is the confidential and proprietary information
// of the IBM Corporation. (‘Confidential Information’). Redistribution
// of the source code or binary form is not permitted without prior authorization
// from the IBM Corporation.
//

#import "AppDelegate.h"
#import <iOSPlayerSDK/iOSPlayerSDK.h>
#import "SampleListViewController.h"

static NSString * const kUstreamPlayerSDKApiKey = @"2jMglxenpqQIzNSWHxDRLT02W2LU8OiLqQ3Rsqwq";

@interface AppDelegate ()
@property(nonatomic, strong) SampleListViewController *sampleListViewController;
@end

@implementation AppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
	[USUstreamPlayer configureWithApiKey:kUstreamPlayerSDKApiKey];
	
	self.sampleListViewController = [[SampleListViewController alloc] init];
	
	self.window = [[UIWindow alloc] initWithFrame:[UIScreen mainScreen].bounds];
	self.window.rootViewController = [[UINavigationController alloc] initWithRootViewController:self.sampleListViewController];
	[self.window makeKeyAndVisible];

	return YES;
}

- (BOOL)application:(UIApplication *)app openURL:(NSURL *)url options:(NSDictionary<UIApplicationOpenURLOptionsKey, id> *)options {
	// Custom url scheme based handling for the hashlock sample. Hash is passed to the app as an url query parameter.
	if ([url.host isEqualToString:@"sdk-sample"] && [url.path isEqualToString:@"/hashlock/pass"]) {
		NSArray *hashComponents = [url.query componentsSeparatedByString:@"="];
		
		if ([hashComponents.firstObject isEqualToString:@"hash"]) {
			NSString *hash = [[hashComponents lastObject] stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
			//The extracted hash is handed to the sample list which then passes it to HashLockViewController.
			[self.sampleListViewController continueWithHash:hash];
		}
		
		return YES;
	}
	
	return NO;
}

@end
