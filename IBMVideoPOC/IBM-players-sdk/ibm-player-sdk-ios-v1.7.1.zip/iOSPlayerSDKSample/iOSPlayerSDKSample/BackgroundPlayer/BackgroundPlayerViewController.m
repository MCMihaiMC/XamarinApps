//
// © Copyright IBM Corp. 2018
//
// All Rights Reserved.
//
// This software is the confidential and proprietary information
// of the IBM Corporation. (‘Confidential Information’). Redistribution
// of the source code or binary form is not permitted without prior authorization
// from the IBM Corporation.
//

#import "BackgroundPlayerViewController.h"
#import <iOSPlayerSDK/iOSPlayerSDK.h>
#import <MediaPlayer/MediaPlayer.h>

/**
 Basic example: fullscreen player with no control user interface.
 */

@interface BackgroundPlayerViewController ()

@property(nonatomic, strong) USUstreamPlayer *player;
@property(nonatomic, strong) UISwitch *backgroundModeSwitch;
@property(nonatomic, strong) UIView *buttonContainer;

@end

@implementation BackgroundPlayerViewController

- (void)viewDidLoad {
	[super viewDidLoad];
	
	self.view.backgroundColor = [UIColor blackColor];
	
	self.edgesForExtendedLayout = UIRectEdgeNone;
	
	self.player = [[USUstreamPlayer alloc] init];
	self.player.playerControlStyle = USPlayerControlStyleDefault;
	CGRect frame = self.view.bounds;
	frame.size.height -= 100;
	self.player.view.frame = frame;
	self.player.view.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
	[self.view addSubview:self.player.view];
	[self setupBackgroundModeButton];
	USMediaDescriptor *mediaDescriptor = [USMediaDescriptor channelDescriptorWithID:@"23308285"];
	[self.player playMedia:mediaDescriptor];
}


- (void)setupBackgroundModeButton {
	CGRect frame = self.player.view.bounds;
	
	self.buttonContainer = [[UIView alloc] initWithFrame:CGRectMake(0, frame.size.height + 50, frame.size.width, 50)];
	self.buttonContainer.autoresizingMask = UIViewAutoresizingFlexibleTopMargin /*| UIViewAutoresizingFlexibleRightMargin | UIViewAutoresizingFlexibleLeftMargin*/;
	
	UILabel *backgroundModeLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 5, 100, 50)];
	backgroundModeLabel.font = [UIFont systemFontOfSize:15];
	backgroundModeLabel.text = @"Continue playback in background";
	backgroundModeLabel.textColor = [UIColor whiteColor];
	[backgroundModeLabel sizeToFit];
	[self.buttonContainer addSubview:backgroundModeLabel];
	
	self.backgroundModeSwitch = [[UISwitch alloc] initWithFrame:CGRectMake(backgroundModeLabel.frame.origin.x + backgroundModeLabel.bounds.size.width + 10, 0, 100, 50)];
	[self.backgroundModeSwitch sizeToFit];
	[self.backgroundModeSwitch addTarget:self action:@selector(backgroundModeSwitchToggled) forControlEvents:UIControlEventTouchUpInside];
	[self.buttonContainer addSubview:self.backgroundModeSwitch];
	CGSize size = CGSizeMake(backgroundModeLabel.frame.origin.x + backgroundModeLabel.bounds.size.width + 10 + self.backgroundModeSwitch.frame.size.width, 50);
	self.buttonContainer.frame = CGRectMake(0,frame.size.height + 50, size.width, size.height);
	self.buttonContainer.center = CGPointMake(frame.origin.x + frame.size.width / 2, self.buttonContainer.center.y);
	[self.view addSubview:self.buttonContainer];
}

- (void)viewWillTransitionToSize:(CGSize)size withTransitionCoordinator:(id<UIViewControllerTransitionCoordinator>)coordinator {
	[coordinator animateAlongsideTransition:^(id<UIViewControllerTransitionCoordinatorContext>  _Nonnull context) {
		CGRect frame = self.player.view.bounds;
		self.buttonContainer.center = CGPointMake(frame.size.width / 2, self.buttonContainer.center.y);
	} completion:^(id<UIViewControllerTransitionCoordinatorContext>  _Nonnull context) {
		
	}];
}

- (void)viewWillDisappear:(BOOL)animated {
	if (self.player.continuePlaybackInBackground) {
		[self removeRemoteCommands];
	}
	[super viewWillDisappear:animated];
}

- (void)backgroundModeSwitchToggled {
	self.player.continuePlaybackInBackground = self.backgroundModeSwitch.on;
	
	// configuring lock screen media playback controls
	[self removeRemoteCommands];
	if (self.player.continuePlaybackInBackground) {
		[self addRemoteCommands];
	}
	
}

- (void)removeRemoteCommands {
	[[MPRemoteCommandCenter sharedCommandCenter].playCommand removeTarget:nil];
	[[MPRemoteCommandCenter sharedCommandCenter].pauseCommand removeTarget:nil];
	[MPNowPlayingInfoCenter defaultCenter].nowPlayingInfo = nil;
}

- (void)addRemoteCommands {
	__weak typeof(self) weakSelf = self;
	[[MPRemoteCommandCenter sharedCommandCenter].playCommand addTargetWithHandler:^MPRemoteCommandHandlerStatus(MPRemoteCommandEvent * _Nonnull event) {
		typeof(self) self = weakSelf;
		[self.player play];
		return MPRemoteCommandHandlerStatusSuccess;
	}];
	[[MPRemoteCommandCenter sharedCommandCenter].pauseCommand addTargetWithHandler:^MPRemoteCommandHandlerStatus(MPRemoteCommandEvent * _Nonnull event) {
		typeof(self) self = weakSelf;
		[self.player pause];
		return MPRemoteCommandHandlerStatusSuccess;
	}];
	
	NSDictionary *nowPlayingInfo = @{MPNowPlayingInfoPropertyIsLiveStream : @(self.player.mediaDescriptor.isChannel),
									 MPMediaItemPropertyTitle : @"Player SDK for Newsfeed"
									 };
	[MPNowPlayingInfoCenter defaultCenter].nowPlayingInfo = nowPlayingInfo;
}

@end
