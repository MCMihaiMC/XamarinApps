//
// © Copyright IBM Corp. 2018
//
// All Rights Reserved.
//
// This software is the confidential and proprietary information
// of the IBM Corporation. (‘Confidential Information’). Redistribution
// of the source code or binary form is not permitted without prior authorization
// from the IBM Corporation.
//

#import "PasswordLockViewController.h"
#import <iOSPlayerSDK/iOSPlayerSDK.h>

/**
 Sample demonstrating the password lock feature.
 */

@interface PasswordLockViewController () <USPlayerDelegate>

@property(nonatomic, strong) USUstreamPlayer *player;

@end

@implementation PasswordLockViewController

- (void)viewDidLoad {
    [super viewDidLoad];
	self.edgesForExtendedLayout = UIRectEdgeNone;
	
	self.player = [[USUstreamPlayer alloc] init];
	self.player.view.frame = self.view.bounds;
	self.player.view.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
	[self.view addSubview:self.player.view];
	
	self.player.delegate = self;

	USMediaDescriptor *mediaDescriptor = [USMediaDescriptor recordedDescriptorWithID:@"108977970"];
	[self.player playMedia:mediaDescriptor];
}

- (void)playerRequiresPassword:(USUstreamPlayer *)player {
	UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Enter password" message:@"Enter \"ibm100+\" to continue." preferredStyle:UIAlertControllerStyleAlert];
	[alertController addTextFieldWithConfigurationHandler:^(UITextField * _Nonnull textField) {
		textField.placeholder = @"Password";
		textField.secureTextEntry = YES;
	}];

	__weak typeof(self) weakSelf = self;
	__weak typeof(alertController) weakAlertController = alertController;
	UIAlertAction *okAction = [UIAlertAction actionWithTitle:@"Ok" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
		UITextField *password = weakAlertController.textFields.firstObject;
		[weakSelf.player continueWithPassword:password.text];
	}];
	UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
	
	}];

	[alertController addAction:okAction];
	[alertController addAction:cancelAction];
	[self presentViewController:alertController animated:YES completion:nil];
}

- (void)viewDidDisappear:(BOOL)animated {
	[super viewDidDisappear:animated];
	if (self.presentedViewController) {
		[self dismissViewControllerAnimated:YES completion:nil];
	}
}

@end
