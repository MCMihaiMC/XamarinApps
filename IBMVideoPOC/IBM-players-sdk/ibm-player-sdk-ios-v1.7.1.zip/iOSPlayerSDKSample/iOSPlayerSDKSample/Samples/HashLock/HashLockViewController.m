//
// © Copyright IBM Corp. 2018
//
// All Rights Reserved.
//
// This software is the confidential and proprietary information
// of the IBM Corporation. (‘Confidential Information’). Redistribution
// of the source code or binary form is not permitted without prior authorization
// from the IBM Corporation.
//

#import "HashLockViewController.h"
#import <iOSPlayerSDK/iOSPlayerSDK.h>
#import <SafariServices/SafariServices.h>

/**
 Basic sample demonstrating hash lock feature.
 */

#define USE_NATIVE_UI	0 // 0 - SFSafariViewController based authentication ui, 1 - UIAlertController based authentication ui

static NSString *const hashlockURL = @"https://openwhisk.eu-gb.bluemix.net/api/v1/web/IBM%20Player%20SDK_dev/ibm-playersdk-sample/hashlock";

@interface HashLockViewController () <USPlayerDelegate>
@property(nonatomic, strong) USUstreamPlayer *player;
@property(nonatomic, strong) SFSafariViewController *safariViewController;
@end

@implementation HashLockViewController

- (void)viewDidLoad {
	[super viewDidLoad];
	self.edgesForExtendedLayout = UIRectEdgeNone;
	
	self.player = [[USUstreamPlayer alloc] init];
	self.player.delegate = self;
	
	self.player.view.frame = self.view.bounds;
	self.player.view.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
	[self.view addSubview:self.player.view];
	
	//Test hash lock username: guest, password: guest
	USMediaDescriptor *mediaDescriptor = [USMediaDescriptor recordedDescriptorWithID:@"109049663"];
	[self.player playMedia:mediaDescriptor];
	
	self.player.playerControlStyle = USPlayerControlStyleNone;
}

- (void)playerRequiresHash:(USUstreamPlayer *)player {
#if USE_NATIVE_UI
	[self presentNativeUI];
#else
	[self presentWebUI];
#endif
}

- (void)presentNativeUI {
	UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Login" message:nil preferredStyle:UIAlertControllerStyleAlert];
	
	[alertController addTextFieldWithConfigurationHandler:^(UITextField * _Nonnull textField) {
		textField.placeholder = @"Username";
	}];
	
	[alertController addTextFieldWithConfigurationHandler:^(UITextField * _Nonnull textField) {
		textField.placeholder = @"Password";
		textField.secureTextEntry = YES;
	}];

	[alertController addTextFieldWithConfigurationHandler:^(UITextField * _Nonnull textField) {
		textField.placeholder = @"Comment";
	}];
	
	__weak typeof(self) weakSelf = self;
	__weak typeof(alertController) weakAlertController = alertController;
	[alertController addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
		NSString *username = weakAlertController.textFields[0].text;
		NSString *password = weakAlertController.textFields[1].text;
		NSString *comment = weakAlertController.textFields[2].text;
		
		[weakSelf loginWithUsername:username password:password comment:comment];
	}]];

	[alertController addAction:[UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
	}]];

	[self presentViewController:alertController animated:YES completion:nil];
}

- (void)loginWithUsername:(NSString *)username password:(NSString *)password comment:(NSString *)comment {
	NSURLComponents *urlComponents = [NSURLComponents componentsWithString:hashlockURL];
	NSURLQueryItem *usernameItem = [NSURLQueryItem queryItemWithName:@"user" value:username];
	NSURLQueryItem *passwordItem = [NSURLQueryItem queryItemWithName:@"pw" value:password];
	NSURLQueryItem *commentItem = [NSURLQueryItem queryItemWithName:@"comment" value:comment];
	urlComponents.queryItems = @[usernameItem, passwordItem, commentItem];
	NSURLSession *session = [NSURLSession sessionWithConfiguration:[NSURLSessionConfiguration defaultSessionConfiguration]];
	NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:urlComponents.URL];
	request.HTTPMethod = @"POST";
	[[session dataTaskWithRequest:request completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
		NSString *hash = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
		if (![hash isEqualToString:@"false"]) {
			[self.player continueWithHash:hash];
		} else {
			dispatch_async(dispatch_get_main_queue(), ^{
				[self playerRequiresHash:self.player];
			});
		}
	}] resume];
}

- (void)presentWebUI {
	NSURLComponents *urlComponents = [NSURLComponents componentsWithString:hashlockURL];
	NSURLQueryItem *queryItem = [NSURLQueryItem queryItemWithName:@"platform" value:@"mobile"];
	urlComponents.queryItems = @[queryItem];
	
	// SFSafariViewController redirects back to sample app if user logged in.
	// AppDelegate handles the redirect and pass the hash to player. URL Scheme is registered in Info.plist.
	self.safariViewController = [[SFSafariViewController alloc] initWithURL:urlComponents.URL];
	[self presentViewController:self.safariViewController animated:YES completion:nil];
}

- (void)continueWithHash:(NSString *)hash {
	[self.safariViewController dismissViewControllerAnimated:YES completion:^{
		if (![hash isEqualToString:@"false"]) {
			[self.player continueWithHash:hash];
		}
	}];
	
	self.safariViewController = nil;
}

@end
