//
// © Copyright IBM Corp. 2018
//
// All Rights Reserved.
//
// This software is the confidential and proprietary information
// of the IBM Corporation. (‘Confidential Information’). Redistribution
// of the source code or binary form is not permitted without prior authorization
// from the IBM Corporation.
//

#import "SimplePlayerViewController.h"
#import <iOSPlayerSDK/iOSPlayerSDK.h>

/**
 Basic example: fullscreen player with no control user interface.
 */

@interface SimplePlayerViewController ()

@property(nonatomic, strong) USUstreamPlayer *player;

@end

@implementation SimplePlayerViewController

- (void)viewDidLoad {
	[super viewDidLoad];
	self.edgesForExtendedLayout = UIRectEdgeNone;
	
	self.player = [[USUstreamPlayer alloc] init];
	self.player.playerControlStyle = USPlayerControlStyleNone;

	self.player.view.frame = self.view.bounds;
	self.player.view.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
	
	[self.view addSubview:self.player.view];
	
	USMediaDescriptor *mediaDescriptor = [USMediaDescriptor channelDescriptorWithID:@"23308285"];
	[self.player playMedia:mediaDescriptor];
}

@end
