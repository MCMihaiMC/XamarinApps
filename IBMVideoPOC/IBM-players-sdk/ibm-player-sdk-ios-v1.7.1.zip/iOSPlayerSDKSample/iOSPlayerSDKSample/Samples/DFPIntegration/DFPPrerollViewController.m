//
// © Copyright IBM Corp. 2018
//
// All Rights Reserved.
//
// This software is the confidential and proprietary information
// of the IBM Corporation. (‘Confidential Information’). Redistribution
// of the source code or binary form is not permitted without prior authorization
// from the IBM Corporation.
//

#import "DFPPrerollViewController.h"
#import <iOSPlayerSDK/iOSPlayerSDK.h>

@interface DFPPrerollViewController ()<USPlayerDelegate>

@property(nonatomic, strong) USUstreamPlayer *player;
@property(nonatomic, strong) USToolbarItem *backButtonItem;
@property(nonatomic, strong) USToolbarItem *titleToolbarItem;
@property(nonatomic, strong) USToolbarItem *sliderToolbarItem;
@property(nonatomic, assign) BOOL fullscreen;

@end

@implementation DFPPrerollViewController

NSString *const kPrerollTestAppAdTagUrl = @"https://pubads.g.doubleclick.net/gampad/ads?sz=640x480&iu=/1044507/sandbox&impl=s&gdfp_req=1&env=vp&output=vast&unviewed_position_start=1";

- (instancetype)init {
	self = [super init];
	if(self) {
		[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(resume) name:UIApplicationDidBecomeActiveNotification object:nil];
		[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(suspend) name:UIApplicationWillResignActiveNotification object:nil];
	}
	return self;
}

- (void)suspend {
	[self.player suspend];
}

- (void)resume {
	[self.player resume];
}

- (void)viewDidLoad {
	[super viewDidLoad];
	self.edgesForExtendedLayout = UIRectEdgeNone;
	
	self.player = [[USUstreamPlayer alloc] init];
	self.player.view.frame = self.view.bounds;
	self.player.view.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
	
	self.player.delegate = self;
	self.player.presentingViewController = self;
	
	[self setupPlayerToolbars];
	
	self.fullscreen = self.view.frame.size.width > self.view.frame.size.height;
	[self.view addSubview:self.player.view];
	
	USMediaDescriptor *mediaDescriptor = [USMediaDescriptor recordedDescriptorWithID:@"109016469"];
	[self.player playMedia:mediaDescriptor];
	[self.player configureAdServiceWithGoogleIMATag:kPrerollTestAppAdTagUrl customMetadata:@{@"test1_kv_predefined":@"Red"} cuePoints:nil allowPreroll:YES];
}

- (void)viewWillDisappear:(BOOL)animated {
	self.navigationController.navigationBarHidden = NO;
	[super viewWillDisappear:animated];
}

- (void)setupPlayerToolbars {
	self.player.playerControlStyle = USPlayerControlStyleToolbar;
	
	NSMutableArray *bottomToolbarItems = [NSMutableArray array];
	[bottomToolbarItems addObject:self.player.playButtonItem];
	[bottomToolbarItems addObjectsFromArray:@[self.player.timeLabelItem,
											  self.sliderToolbarItem,
											  self.player.durationLabelItem,
											  self.player.subtitlesButtonItem
											  ]];
	
	[self.player.topToolbar setToolbarItems:@[self.titleToolbarItem] animated:NO];
	[self.player.bottomToolbar setToolbarItems:bottomToolbarItems animated:NO];
}

- (USToolbarItem *)titleToolbarItem {
	if (!_titleToolbarItem) {
		_titleToolbarItem = self.player.titleLabelItem;
		_titleToolbarItem.toolbarAutoresizingMask = USToolbarAutoresizingFlexibleWidth;
	}
	
	return _titleToolbarItem;
}

- (USToolbarItem *)sliderToolbarItem {
	if (!_sliderToolbarItem) {
		_sliderToolbarItem = self.player.sliderItem;
		_sliderToolbarItem.toolbarAutoresizingMask = USToolbarAutoresizingFlexibleWidth;
	}
	
	return _sliderToolbarItem;
}

- (USToolbarItem *)backButtonItem {
	if (!_backButtonItem) {
		UIButton *backButton = [UIButton buttonWithType:UIButtonTypeCustom];
		[backButton setImage:[UIImage imageNamed:@"backButton"] forState:UIControlStateNormal];
		[backButton addTarget:self action:@selector(backButtonPressed:) forControlEvents:UIControlEventTouchUpInside];
		backButton.frame = CGRectMake(0, 0, 32, 32);
		
		_backButtonItem = [USToolbarItem itemWithCustomView:backButton];
		_backButtonItem.toolbarAutoresizingMask = USToolbarAutoresizingFixedWidth;
		[_backButtonItem sizeToFit];
	}
	
	return _backButtonItem;
}

- (void)backButtonPressed:(id)sender {
	[self.navigationController popViewControllerAnimated:YES];
}

- (void)setFullscreen:(BOOL)fullscreen {
	if (_fullscreen == fullscreen) return;
	_fullscreen = fullscreen;
	
	[UIView animateWithDuration:0.3 animations:^{
		if (fullscreen) {
			self.player.view.frame = self.view.bounds;
			[self.view addSubview:self.player.view];
		} else {
			self.player.view.frame = self.view.bounds;
			[self.view addSubview:self.player.view];
		}
	}];
	
	//In landscape orientation hide navigation bar and add an extra back button toolbar item in the top toolbar.
	[self.player.topToolbar setToolbarItems:_fullscreen ? @[self.backButtonItem, self.titleToolbarItem] : @[self.titleToolbarItem] animated:YES];
	self.navigationController.navigationBarHidden = fullscreen;
	[self setNeedsStatusBarAppearanceUpdate];
}

- (BOOL)prefersStatusBarHidden {
	return self.fullscreen;
}

- (void)viewWillTransitionToSize:(CGSize)size withTransitionCoordinator:(id<UIViewControllerTransitionCoordinator>)coordinator {
	[super viewWillTransitionToSize:size withTransitionCoordinator:coordinator];
	
	BOOL isPhone = (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone);
	if (isPhone) {
		self.fullscreen = (size.width > size.height);
	}
}

#pragma mark - USUstreamPlayerDelegate

- (NSDictionary *)player:(USUstreamPlayer *)player willLoadAdWithCustomParameters:(NSDictionary *)customParameters {
	NSMutableDictionary *modifiedParameters = [NSMutableDictionary dictionaryWithDictionary:customParameters];
	modifiedParameters[@"my_ad_targeting_custom_parameter"] = @"TestAd";
	
	NSLog(@"Loading ad for placement: %@", customParameters[USUstreamPlayerAdPlacementKey]);
	return modifiedParameters;
}

- (void)playerStartingAd:(USUstreamPlayer *)player {
	NSLog(@"Playing ad");
}

- (void)playerDidFinishPlayingAd:(USUstreamPlayer *)player {
	NSLog(@"Finished playing ad");
}

- (void)player:(USUstreamPlayer *)player receivedAdError:(NSError *)error {
	NSLog(@"received ad error: %@", error);
}


@end
