//
// © Copyright IBM Corp. 2018
//
// All Rights Reserved.
//
// This software is the confidential and proprietary information
// of the IBM Corporation. (‘Confidential Information’). Redistribution
// of the source code or binary form is not permitted without prior authorization
// from the IBM Corporation.
//

#import "OfflineChannelViewController.h"
#import <iOSPlayerSDK/iOSPlayerSDK.h>

/**
 Sample demonstrating how to detect and handle live and offline channels.
 */

@interface OfflineChannelViewController ()<USPlayerDelegate>

@property(nonatomic, strong) USUstreamPlayer *player;

@end

@implementation OfflineChannelViewController

- (void)viewDidLoad {
	[super viewDidLoad];
	self.edgesForExtendedLayout = UIRectEdgeNone;
	
	self.player = [[USUstreamPlayer alloc] init];
	self.player.playerControlStyle = USPlayerControlStyleNone;

	self.player.view.frame = self.view.bounds;
	self.player.view.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;

	self.player.delegate = self;
	[self.view addSubview:self.player.view];
	
	//Replace media descriptor below with a channel you have control of. Starting and stopping broadcast in this channel causes the player to call its delegate method -playerLiveStateDidChange: so additional app logic can be built upon this event.
	USMediaDescriptor *mediaDescriptor = [USMediaDescriptor channelDescriptorWithID:@"23439002"];
	[self.player playMedia:mediaDescriptor];
}

- (void)playerLiveStateDidChange:(USUstreamPlayer *)player {
	if (player.isLive) {
		NSLog(@"Player is playing a channel with live content.");
		//Additional app logic if player goes on-air.
	} else {
		NSLog(@"Player is playing an offline channel.");
		//Additional app logic if player goes off-air.
	}
}

@end
