//
// © Copyright IBM Corp. 2018
//
// All Rights Reserved.
//
// This software is the confidential and proprietary information
// of the IBM Corporation. (‘Confidential Information’). Redistribution
// of the source code or binary form is not permitted without prior authorization
// from the IBM Corporation.
//

#import <UIKit/UIKit.h>
#import "VideoContentCell.h"

NSString *const VideoThumbnailImageNameKey = @"Image";
NSString *const VideoRecordedIDKey = @"VideoRecordedID";
NSString *const VideoChannelIDKey = @"VideoLiveID";
NSString *const VideoMetaKey = @"Meta";

@interface VideoContentCell () 
@property(nonatomic, weak) IBOutlet UIView *playerContainer;
@property(nonatomic, weak) IBOutlet UILabel *metaField;
@property(nonatomic, assign) CGRect playerFrame;
@property(nonatomic, strong) UIImageView *thumbnailImageView;
@property(nonatomic, strong) UIView *overlayBackgroundView;
@property(nonatomic, strong) NSURLSessionDataTask *thumbnailDownloadTask;
@end

@implementation VideoContentCell

- (void)awakeFromNib {
	[super awakeFromNib];
	self.thumbnailImageView = [[UIImageView alloc] init];
	self.thumbnailImageView.contentMode = UIViewContentModeScaleAspectFill;
	self.thumbnailImageView.clipsToBounds = YES;
    self.thumbnailImageView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
	[self.playerContainer addSubview:self.thumbnailImageView];
	
	self.overlayBackgroundView = [[UIView alloc] initWithFrame:self.playerContainer.bounds];
	self.overlayBackgroundView.backgroundColor = [UIColor colorWithWhite:0 alpha:0.26];
	self.overlayBackgroundView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;

	[self.playerContainer addSubview:self.overlayBackgroundView];
	
	CGFloat playerHeight = CGRectGetWidth(self.playerContainer.bounds) * 9 / 16;
	self.playerFrame = CGRectMake(0, CGRectGetMaxY(self.playerContainer.bounds) - playerHeight, CGRectGetWidth(self.playerContainer.bounds), playerHeight);
	self.selectionStyle = UITableViewCellSelectionStyleNone;
}

- (void)setContent:(NSDictionary *)content {
	[super setContent:content];
    
    if (self.content[VideoThumbnailImageNameKey]) {
        self.thumbnailDownloadTask = [[NSURLSession sharedSession] dataTaskWithURL:[NSURL URLWithString:self.content[VideoThumbnailImageNameKey]] completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
            if (!error && data) {
                UIImage *image = [UIImage imageWithData:data];
                dispatch_async(dispatch_get_main_queue(), ^{
                    self.thumbnailImageView.image = image;
                    [self setNeedsLayout];
                });
            }
        }];
        [self.thumbnailDownloadTask resume];
        
        self.metaField.text = self.content[VideoMetaKey];
        [self setNeedsLayout];
    } else {

    }
}

- (void)layoutSubviews {
	[super layoutSubviews];
	
	CGFloat playerHeight = CGRectGetWidth(self.playerContainer.bounds) * 9 / 16;
	self.playerFrame = CGRectMake(0, CGRectGetMaxY(self.playerContainer.bounds) - playerHeight, CGRectGetWidth(self.playerContainer.bounds), playerHeight);
	
	self.thumbnailImageView.frame = self.playerFrame;
	self.player.view.frame = self.playerFrame;
}

- (void)prepareForReuse {
	[super prepareForReuse];
    [self.thumbnailDownloadTask cancel];
	self.player = nil;
}

- (void)setPlayer:(USUstreamPlayer *)player {
	if (_player == player) return;
	
	if([_player.view isDescendantOfView:self]) {
		[_player.view removeFromSuperview];
	}
	_player = player;
	
	if (_player) {
		_player.view.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
		_player.view.frame = self.playerFrame;
		_player.delegate = self;
		[self.playerContainer addSubview:_player.view];
		[self updateViewVisibility];
	}
}

- (void)playerStateDidChange:(USUstreamPlayer *)player {
	[self updateViewVisibility];
	if (player.playerState == USPlayerStatePlaying) {
		[player selectLegibleMediaSelectionOption:player.defaultLegibleMediaSelectionOption];
	}
}

- (void)updateViewVisibility {
	[self.playerContainer sendSubviewToBack:self.contentImageView];
	[self.playerContainer bringSubviewToFront:self.player.view];
	[self.playerContainer bringSubviewToFront:self.overlayBackgroundView];
	
	BOOL isThumbnailVisible = (self.player.playerState == USPlayerStateStopped ||
							   self.player.playerState == USPlayerStateLoading ||
							   self.player.playerState == USPlayerStateWaiting ||
							   self.player.playerState == USPlayerStateReadyToPlay);
	
	BOOL isOverlayVisible = (self.player.playerState == USPlayerStateStopped ||
							 self.player.playerState == USPlayerStateLoading ||
							 self.player.playerState == USPlayerStateWaiting ||
							 self.player.playerState == USPlayerStateReadyToPlay ||
							 self.player.playerState == USPlayerStatePaused);
	
	BOOL isPlayerVisible = (self.player.playerState == USPlayerStatePlaying ||
							self.player.playerState == USPlayerStatePaused ||
							self.player.playerState == USPlayerStateFailed);
	
	NSAssert((isThumbnailVisible && isOverlayVisible && !isPlayerVisible) || (isPlayerVisible && !isThumbnailVisible), @"Invalid state!");
	
	self.thumbnailImageView.hidden = !isThumbnailVisible;
	self.overlayBackgroundView.hidden = !isOverlayVisible;
	self.player.view.hidden = !isPlayerVisible;
}

@end
