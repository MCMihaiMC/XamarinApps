//
// © Copyright IBM Corp. 2018
//
// All Rights Reserved.
//
// This software is the confidential and proprietary information
// of the IBM Corporation. (‘Confidential Information’). Redistribution
// of the source code or binary form is not permitted without prior authorization
// from the IBM Corporation.
//

#import "ContentCell.h"
#import <ImageIO/ImageIO.h>

NSString *const ContentCardNameKey = @"Image";
NSString *const BodyKey = @"Body";
NSString *const TitleKey = @"Title";

@interface ContentCell ()

@property(nonatomic, weak) IBOutlet UIImageView *contentImageView;
@property(nonatomic, weak) IBOutlet UILabel *titleLabel;
@property(nonatomic, weak) IBOutlet UILabel *bodyLabel;

@end

@implementation ContentCell

- (void)awakeFromNib {
	[super awakeFromNib];
	self.selectionStyle = UITableViewCellSelectionStyleNone;
}

- (void)prepareForReuse {
	[super prepareForReuse];
	self.content = nil;
}

- (void)setContent:(NSDictionary *)content {
	_content = content;
	if (content[ContentCardNameKey]) {
		self.contentImageView.image = [UIImage imageNamed:content[ContentCardNameKey]];
	}
	self.titleLabel.text = content[TitleKey];
	self.bodyLabel.text = content[BodyKey];
	
}

@end
