//
// © Copyright IBM Corp. 2018
//
// All Rights Reserved.
//
// This software is the confidential and proprietary information
// of the IBM Corporation. (‘Confidential Information’). Redistribution
// of the source code or binary form is not permitted without prior authorization
// from the IBM Corporation.
//

#import "PrebufferedNewsfeedViewController.h"
#import "VideoContentCell.h"
#import <iOSPlayerSDK/iOSPlayerSDK.h>

static NSInteger const PlayerPrepareWindowOffset = 0;

/**
 Example demonstrating the basic usage of USPrebufferingController in the form of a tableview containing video cells. The videos are prebuffered and autoplayed once in focus.
 */

@interface PrebufferedNewsfeedViewController () <UITableViewDataSource, UITableViewDelegate, USPrebufferingDelegate>
// Model for table view that mimics the feed content
@property(nonatomic, strong) NSArray *feedContent;
// Table view that lists cards of feed content
@property(nonatomic, strong) UITableView *tableView;
// Player controller is the new API for playback preparation to achieve instant autoplay
@property(nonatomic, strong) USPrebufferingController *prebufferingController;
// The active player, either in-cell or fullscreen
@property(nonatomic, weak) USUstreamPlayer *activePlayer;
// The index path of the cell that contains the active player
@property(nonatomic, strong) NSIndexPath *playingIndexPath;
// Dictionary of video content found in the feed, keys are index paths of video cells, values are recorded ids
@property(nonatomic, strong) NSMutableDictionary<NSIndexPath *, USMediaDescriptor*> *videoItems;
@end

@implementation PrebufferedNewsfeedViewController

#pragma mark - View lifecycle

- (void)loadView {
	[super loadView];
	self.videoItems = [NSMutableDictionary dictionary];
	self.prebufferingController = [[USPrebufferingController alloc] init];
	self.prebufferingController.delegate = self;

	self.tableView = [[UITableView alloc] initWithFrame:self.view.bounds style:UITableViewStylePlain];
	self.tableView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
	self.tableView.dataSource = self;
	self.tableView.delegate = self;
	
	self.tableView.rowHeight = UITableViewAutomaticDimension;
	self.tableView.estimatedRowHeight = 420;
	
	[self.tableView registerNib:[UINib nibWithNibName:NSStringFromClass(ContentCell.class) bundle:nil] forCellReuseIdentifier:NSStringFromClass(ContentCell.class)];
	[self.tableView registerNib:[UINib nibWithNibName:NSStringFromClass(VideoContentCell.class) bundle:nil] forCellReuseIdentifier:NSStringFromClass(VideoContentCell.class)];
	self.tableView.backgroundColor = [UIColor whiteColor];
	
	[self.view addSubview:self.tableView];
}

- (void)viewDidLoad {
	[super viewDidLoad];
	[self loadContent];
}

#pragma mark - Content loading

- (void)loadContent {
	self.feedContent = [NSArray arrayWithContentsOfURL:[[NSBundle mainBundle] URLForResource:@"ContentList" withExtension:@"plist"]];
	for (NSInteger i = 0; i < self.feedContent.count; i++) {
		NSString *videoID = self.feedContent[i][VideoRecordedIDKey];
		NSString *channelID = self.feedContent[i][VideoChannelIDKey];
		if (videoID != nil) {
			self.videoItems[[NSIndexPath indexPathForRow:i inSection:0]] = [USMediaDescriptor recordedDescriptorWithID:videoID];
		} else 	if (channelID != nil) {
			self.videoItems[[NSIndexPath indexPathForRow:i inSection:0]] = [USMediaDescriptor channelDescriptorWithID:channelID];
		}
	}
	[self.tableView reloadData];
	[self prepareNearbyVideosToPlay];
	[self autoplayVideoInFocus];
}

#pragma mark - Table view

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
	return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
	return self.feedContent.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
	Class cellClass = [self cellClassForIndexPath:indexPath];
	UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:NSStringFromClass(cellClass) forIndexPath:indexPath];
	if (!cell) {
		cell = [[cellClass alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:NSStringFromClass(cellClass)];
	}
	BOOL isContentCell = (indexPath.row < self.feedContent.count);
	if (!isContentCell) return cell; // Loading cell
	ContentCell *contentCell = (ContentCell *)cell;
	contentCell.content = self.feedContent[indexPath.row];
	// If the cell contains video content, a prebuffered player gets assigned to it
	if ([contentCell isKindOfClass:[VideoContentCell class]]) {
		((VideoContentCell *)contentCell).media = self.videoItems[indexPath];
		
		[self embedPlayerInVideoContentCell:(VideoContentCell *)contentCell];
	}
	return cell;
}

- (Class)cellClassForIndexPath:(NSIndexPath *)indexPath {
	NSDictionary *content = self.feedContent[indexPath.row];
	if ([content[@"Type"] isEqualToString:@"VideoPost"]) {
		return [VideoContentCell class];
	}
	return [ContentCell class];
}

#pragma mark - Player

// A prebuffered player gets embedded in the video cell
- (void)embedPlayerInVideoContentCell:(VideoContentCell *)videoCell {
	NSParameterAssert(videoCell != nil);
	USMediaDescriptor *media = videoCell.media;
	if (media) {
		USUstreamPlayer *player = [self.prebufferingController playerForMedia:media];
		videoCell.player = player;
	}
	videoCell.player.presentingViewController = self;
}

#pragma mark - Autoplay

// Autoplay and player preparation logic is based on the table view's scrolling position, whenever the table view scrolls, we check for nearby videos.
- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
	[self prepareNearbyVideosToPlay];
	[self autoplayVideoInFocus];
}

// When a video cell scrolls into the visible portion of the table view, playback is started automatically.
- (void)autoplayVideoInFocus {
	// Currently the whole table view is the focus area
	CGFloat focusHeight = self.tableView.frame.size.height - PlayerPrepareWindowOffset;
	CGRect focusArea = CGRectMake(0, self.tableView.contentOffset.y + PlayerPrepareWindowOffset, self.view.bounds.size.width, focusHeight);
	NSIndexPath *focusedVideoIndexPath = nil;
	
	// We go through the visible cells and if we find a video cell, we check whether its player is fully covered by the focus area.
	// If the focus area fully contains the player, we consider the video content to be focused by the user and we start the playback.
	for (NSIndexPath *indexPath in [self.tableView indexPathsForVisibleRows]) {
		ContentCell *visibleCell = (ContentCell *)[self.tableView cellForRowAtIndexPath:indexPath];
		if (![visibleCell isKindOfClass:[VideoContentCell class]]) continue;
		CGRect playerFrame = [self.tableView convertRect:((VideoContentCell *)visibleCell).playerFrame fromView:((VideoContentCell *)visibleCell).playerContainer];
		if (CGRectContainsRect(focusArea, playerFrame)) {
			focusedVideoIndexPath = indexPath;
			break;
		}
	}
	
	// If focusedVideoIndexPath is not nil, it means that video content is in focus, so we fetch its recorded id
	USMediaDescriptor *focusedMedia = (focusedVideoIndexPath ? self.videoItems[focusedVideoIndexPath] : nil);
	[self playVideo:focusedMedia atIndexPath:focusedVideoIndexPath];
}

// Start playback of the provided recorded id
- (void)playVideo:(USMediaDescriptor *)media atIndexPath:(NSIndexPath *)indexPath {
	if (indexPath == self.playingIndexPath || [indexPath isEqual:self.playingIndexPath]) return;
	
	[self.activePlayer pause];
	
	if (!media) {
		// If media is nil, it means that there is no video content in focus, so we stop the active playback
		self.activePlayer = nil;
		self.playingIndexPath = nil;
	} else {
		// If media is not nil, we fetch a player for it that's already prebuffered
		self.activePlayer = [self.prebufferingController playerForMedia:media];
		[self.activePlayer play];
		self.playingIndexPath = indexPath;
	}
}

- (void)prepareNearbyVideosToPlay {
	NSArray<NSIndexPath *> *visibleIndexPaths = [self.tableView indexPathsForVisibleRows];
	NSInteger firstVisibleRow = [visibleIndexPaths firstObject].row;
	NSInteger lastVisibleRow = [visibleIndexPaths lastObject].row;
	
	CGFloat origo = (CGFloat)(firstVisibleRow + lastVisibleRow) / 2.0f;
	NSArray *indexPaths = [self.videoItems.allKeys sortedArrayUsingComparator:^NSComparisonResult(NSIndexPath *indexPath1, NSIndexPath *indexPath2) {
		CGFloat distance1 = fabs(indexPath1.row - origo);
		CGFloat distance2 = fabs(indexPath2.row - origo);
		return (distance1 < distance2 ? NSOrderedAscending : NSOrderedDescending);
	}];
	
	NSMutableArray *videosToPrepare = [NSMutableArray new];
	for (NSIndexPath *indexPath in indexPaths) {
		USMediaDescriptor *media = [self.videoItems objectForKey:indexPath];
		if (media != nil) {
			[videosToPrepare addObject:media];
		}
	}
	[self.prebufferingController enqueueForPlaybackPreparation:videosToPrepare];
}

#pragma mark - USPrebufferingDelegate

// TODO:X handle these callbacks in sample
- (BOOL)prebufferingController:(USPrebufferingController *)prebufferingController reportsLoadingError:(NSError *)error forMedia:(USMediaDescriptor *)media {
	NSLog(@"media loading failed: %@ with error: %@", media, error);
	return YES;
}

- (void)prebufferingController:(USPrebufferingController *)prebufferingController requiresPasswordForMedia:(USMediaDescriptor *)media {
	
}

- (void)prebufferingController:(USPrebufferingController *)prebufferingController requiresBirthdateForMedia:(USMediaDescriptor *)media {
	
}

- (void)prebufferingController:(USPrebufferingController *)prebufferingController requiresHashForMedia:(USMediaDescriptor *)media {
	
}

@end

