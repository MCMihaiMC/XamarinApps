//
// © Copyright IBM Corp. 2018
//
// All Rights Reserved.
//
// This software is the confidential and proprietary information
// of the IBM Corporation. (‘Confidential Information’). Redistribution
// of the source code or binary form is not permitted without prior authorization
// from the IBM Corporation.
//

#import "ContentCell.h"
#import <iOSPlayerSDK/iOSPlayerSDK.h>

NS_ASSUME_NONNULL_BEGIN

extern NSString *const VideoThumbnailImageNameKey;
extern NSString *const VideoRecordedIDKey;
extern NSString *const VideoChannelIDKey;

@interface VideoContentCell : ContentCell <USPlayerDelegate>
@property(nonatomic, weak, readonly) IBOutlet UIView *playerContainer;
@property(nonatomic, assign, readonly) CGRect playerFrame;
@property(nonatomic, strong, nullable) USUstreamPlayer *player;
@property(nonatomic, strong) USMediaDescriptor *media;
@end

NS_ASSUME_NONNULL_END
