//
// © Copyright IBM Corp. 2018
//
// All Rights Reserved.
//
// This software is the confidential and proprietary information
// of the IBM Corporation. (‘Confidential Information’). Redistribution
// of the source code or binary form is not permitted without prior authorization
// from the IBM Corporation.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

extern NSString *const ContentCardNameKey;

@interface ContentCell : UITableViewCell

@property(nonatomic, weak, readonly) UIImageView *contentImageView;
@property(nonatomic, strong, nullable) NSDictionary *content;

- (void)setContent:(nullable NSDictionary *)content NS_REQUIRES_SUPER;

@end

NS_ASSUME_NONNULL_END
