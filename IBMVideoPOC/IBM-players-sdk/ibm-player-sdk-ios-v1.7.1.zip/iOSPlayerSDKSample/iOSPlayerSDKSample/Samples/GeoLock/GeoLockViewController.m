//
// © Copyright IBM Corp. 2018
//
// All Rights Reserved.
//
// This software is the confidential and proprietary information
// of the IBM Corporation. (‘Confidential Information’). Redistribution
// of the source code or binary form is not permitted without prior authorization
// from the IBM Corporation.
//

#import "GeoLockViewController.h"
#import <iOSPlayerSDK/iOSPlayerSDK.h>

/**
 Sample demonstrating the geolock feature.
 */

@interface GeoLockViewController ()

@property(nonatomic, strong) USUstreamPlayer *player1;
@property(nonatomic, strong) USUstreamPlayer *player2;

@end

@implementation GeoLockViewController

- (void)viewDidLoad {
    [super viewDidLoad];
	self.edgesForExtendedLayout = UIRectEdgeNone;
	self.player1 = [[USUstreamPlayer alloc] init];
	[self.view addSubview:self.player1.view];
	
	self.player2 = [[USUstreamPlayer alloc] init];
	[self.view addSubview:self.player2.view];

	//The following media is configured to be playable only outside of the US.
	USMediaDescriptor *mediaDescriptor1 = [USMediaDescriptor recordedDescriptorWithID:@"108978504"];
	[self.player1 playMedia:mediaDescriptor1];

	//The following media is configured to be playable only from the US.
	USMediaDescriptor *mediaDescriptor2 = [USMediaDescriptor recordedDescriptorWithID:@"109049415"];
	[self.player2 playMedia:mediaDescriptor2];

}

- (void)viewWillLayoutSubviews {
	[super viewWillLayoutSubviews];
	self.player1.view.frame = CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height / 2);
	self.player2.view.frame = CGRectMake(0, self.view.frame.size.height / 2, self.view.frame.size.width, self.view.frame.size.height / 2);
}

@end
