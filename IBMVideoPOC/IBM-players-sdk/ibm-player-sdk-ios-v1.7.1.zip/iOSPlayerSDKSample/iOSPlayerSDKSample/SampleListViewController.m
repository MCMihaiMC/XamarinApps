//
// © Copyright IBM Corp. 2018
//
// All Rights Reserved.
//
// This software is the confidential and proprietary information
// of the IBM Corporation. (‘Confidential Information’). Redistribution
// of the source code or binary form is not permitted without prior authorization
// from the IBM Corporation.
//

#import "SampleListViewController.h"
#import "HashLockViewController.h"
#import "SimplePlayerViewController.h"
#import "CustomizedPlayerViewController.h"
#import "BackgroundPlayerViewController.h"
#import "PrebufferedNewsfeedViewController.h"
#import "PasswordLockViewController.h"
#import "GeoLockViewController.h"
#import "HashLockViewController.h"
#import "OfflineChannelViewController.h"
#import "DFPPrerollViewController.h"
#import "DFPMidrollViewController.h"

@interface SampleListViewController ()

@property (nonatomic, strong) NSArray *sampleList;
@property (nonatomic, weak) UIViewController *detailViewController;

@end

@implementation SampleListViewController

- (void)viewDidLoad {
    [super viewDidLoad];
	self.title = @"IBM Player SDK Samples";
	self.sampleList = @[
						@{
							@"name":@"Simple Player",
							@"class":SimplePlayerViewController.class
						  },
						@{
							@"name":@"Customized Player",
							@"class":CustomizedPlayerViewController.class
							},
						@{
							@"name":@"Background Player",
							@"class":BackgroundPlayerViewController.class
							},
						@{
							@"name":@"Prebuffered Newsfeed",
							@"class":PrebufferedNewsfeedViewController.class
							},
						@{
							@"name":@"Password lock",
							@"class":PasswordLockViewController.class
							},
						@{
							@"name":@"Geo lock",
							@"class":GeoLockViewController.class
							},
						@{
							@"name":@"Hash lock",
							@"class":HashLockViewController.class
							},
						@{
							@"name":@"Offline Channel",
							@"class":OfflineChannelViewController.class
							},
						@{
							@"name":@"DFP Preroll",
							@"class":DFPPrerollViewController.class
							},
						@{
							@"name":@"DFP Midroll",
							@"class":DFPMidrollViewController.class
							},
						];
	[self.tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:@"cell"];
}

#pragma mark - Hash delegate method

- (void)continueWithHash:(NSString *)hash {
	if ([self.detailViewController isKindOfClass:[HashLockViewController class]]) {
		[(HashLockViewController *)self.detailViewController continueWithHash:hash];
	}
}

#pragma mark - Table view data source

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.sampleList.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell" forIndexPath:indexPath];
	if (!cell) {
		cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell"];
	}
	cell.textLabel.text = self.sampleList[indexPath.row][@"name"];

	return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
	UIViewController *viewController = [[self.sampleList[indexPath.row][@"class"] alloc] init];
	self.detailViewController = viewController;
	[self.navigationController pushViewController:self.detailViewController animated:YES];
}

@end
